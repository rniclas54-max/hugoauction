# HugoAuction — Fabric / Minecraft 26.3

This is a **source project**, not a prebuilt/tested JAR. It is intended to be built with Java 25, Gradle 9.6 and Fabric Loom 1.17 for Minecraft 26.3.

## Build
1. Install a JDK 25.
2. Install Gradle 9.6 (or add the official Gradle wrapper to this project).
3. Open a terminal in this folder and run `gradle build`.
4. The output should be in `build/libs/`.
5. Copy the resulting `HugoAuction-26.3-0.1.0.jar` to your Minecraft `mods` folder.

Fabric API is required. The project uses the 26.3 Fabric API version `0.162.0+26.3`.

## In game
- `/hauction` opens the auction window.
- `/hauction test Name 500` simulates a payment to test the ranking.

## Important limitations
- Chat payment recognition uses sample English/German patterns and may need to be adapted to HugoSMP's exact payment message.
- This client-only helper cannot transfer the item. Give it to the winner manually.
- This project has **not been compiled or tested here**. Minecraft 26.3 changed APIs, so fix any build/API errors before relying on it in-game. Back up your mods folder and test in a safe environment.

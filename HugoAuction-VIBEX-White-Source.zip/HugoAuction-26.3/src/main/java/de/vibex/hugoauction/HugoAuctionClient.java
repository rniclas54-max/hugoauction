package de.vibex.hugoauction;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class HugoAuctionClient implements ClientModInitializer {
    public static final AuctionState STATE = new AuctionState();

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("hauction")
                .executes(context -> {
                    Minecraft client = Minecraft.getInstance();
                    client.execute(() -> client.setScreen(new AuctionScreen()));
                    return 1;
                })
                .then(literal("test")
                    .then(net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument("name", com.mojang.brigadier.arguments.StringArgumentType.word())
                        .then(net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument("amount", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1))
                            .executes(context -> {
                                String name = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "name");
                                int amount = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "amount");
                                STATE.addPayment(name, amount);
                                context.getSource().sendFeedback(Component.literal("[HugoAuction] Testgebot: " + name + " +$" + amount));
                                return 1;
                            }))))));

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            String text = message.getString();
            ChatParser.parsePayment(text).ifPresent(payment -> STATE.addPayment(payment.name(), payment.amount()));
        });
    }
}

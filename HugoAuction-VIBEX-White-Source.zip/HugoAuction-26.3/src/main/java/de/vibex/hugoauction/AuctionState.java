package de.vibex.hugoauction;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Comparator;
import java.util.List;

public final class AuctionState {
    private String itemName = "Item in der Hand";
    private int minimumBid = 1;
    private long endAtMillis;
    private boolean running;
    private final Map<String, Integer> totals = new LinkedHashMap<>();

    public synchronized void start(String item, int minimum, int seconds) {
        itemName = item == null || item.isBlank() ? "Item" : item;
        minimumBid = Math.max(1, minimum);
        endAtMillis = System.currentTimeMillis() + Math.max(1, seconds) * 1000L;
        totals.clear();
        running = true;
    }
    public synchronized void stop() { running = false; }
    public synchronized void reset() { running = false; totals.clear(); endAtMillis = 0; }
    public synchronized boolean isRunning() { return running && remainingMillis() > 0; }
    public synchronized long remainingMillis() { return Math.max(0, endAtMillis - System.currentTimeMillis()); }
    public synchronized String itemName() { return itemName; }
    public synchronized int minimumBid() { return minimumBid; }
    public synchronized int totalIncome() { return totals.values().stream().mapToInt(Integer::intValue).sum(); }
    public synchronized int highestBid() { return totals.values().stream().mapToInt(Integer::intValue).max().orElse(0); }
    public synchronized String highestBidder() {
        return ranking().stream().findFirst().map(Map.Entry::getKey).orElse("");
    }
    public synchronized void addPayment(String name, int amount) {
        if (name == null || name.isBlank() || amount <= 0) return;
        totals.merge(name, amount, Integer::sum);
    }
    public synchronized List<Map.Entry<String,Integer>> ranking() {
        return totals.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue(Comparator.reverseOrder())).toList();
    }
    public synchronized String winner() {
        return ranking().stream().filter(e -> e.getValue() >= minimumBid).findFirst().map(Map.Entry::getKey).orElse("Niemand (Mindestgebot nicht erreicht)");
    }
}

package de.vibex.hugoauction;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Monochrome VIBEX-branded client-side auction screen. */
public final class AuctionScreen extends Screen {
    private EditBox minimumField;
    private int durationSeconds = 60;
    private Button durationButton;

    private static final int OUTER = 0xF0181818;
    private static final int PANEL = 0xE82B2B2B;
    private static final int PANEL_LIGHT = 0xE8464646;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFDDDDDD;
    private static final int BORDER = 0xFFFFFFFF;

    public AuctionScreen() { super(Component.literal("VIBEX AUCTION")); }

    @Override
    protected void init() {
        clearWidgets();
        int cx = width / 2;
        int top = height / 2 - 105;
        int left = cx - 155;

        minimumField = new EditBox(font, left + 18, top + 91, 284, 20, Component.literal("Mindestgebot in $") );
        minimumField.setValue("500");
        minimumField.setHint(Component.literal("Mindestgebot in $") );
        minimumField.setFilter(s -> s.matches("[0-9]{0,9}"));
        addRenderableWidget(minimumField);

        durationButton = Button.builder(durationLabel(), b -> {
            int[] values = {30, 45, 60, 120, 300, 600};
            int idx = 0;
            for (int i = 0; i < values.length; i++) if (values[i] == durationSeconds) idx = i;
            durationSeconds = values[(idx + 1) % values.length];
            b.setMessage(durationLabel());
        }).bounds(left + 18, top + 53, 284, 20).build();
        addRenderableWidget(durationButton);

        addRenderableWidget(Button.builder(Component.literal("▶  Starten"), b -> startAuction())
            .bounds(left + 18, top + 119, 284, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Werbung"), b -> advertise())
            .bounds(left + 18, top + 151, 88, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Zurücksetzen"), b -> HugoAuctionClient.STATE.reset())
            .bounds(left + 112, top + 151, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Schließen"), b -> onClose())
            .bounds(left + 222, top + 151, 80, 20).build());
    }

    private Component durationLabel() {
        String duration = durationSeconds < 60 ? durationSeconds + " Sekunden" : durationSeconds / 60 + " Minute" + (durationSeconds == 60 ? "" : "n");
        return Component.literal("Dauer: " + duration + "  ▾");
    }

    private void startAuction() {
        int minimum;
        try { minimum = Integer.parseInt(minimumField.getValue()); }
        catch (NumberFormatException e) { minimum = 1; }
        String item = "Unbekanntes Item";
        var player = Minecraft.getInstance().player;
        if (player != null && !player.getMainHandItem().isEmpty()) item = player.getMainHandItem().getHoverName().getString();
        HugoAuctionClient.STATE.start(item, minimum, durationSeconds);
        advertise();
    }

    private void advertise() {
        var player = Minecraft.getInstance().player;
        if (player != null) player.connection.sendChat("[VIBEX AUCTION] " + HugoAuctionClient.STATE.itemName()
            + " | Mindestgebot: $" + HugoAuctionClient.STATE.minimumBid()
            + " | Zahle mit /pay " + player.getName().getString() + " Betrag");
    }

    private void finishAuction() {
        HugoAuctionClient.STATE.stop();
        var player = Minecraft.getInstance().player;
        if (player != null) player.connection.sendChat("[VIBEX AUCTION] Auktion beendet! Gewinner: "
            + HugoAuctionClient.STATE.winner() + " | Übergabe bitte manuell.");
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int cx = width / 2;
        int top = height / 2 - 105;
        int left = cx - 155;
        int right = cx + 155;

        // Outer monochrome frame and header
        g.fill(left - 5, top - 5, right + 5, top + 255, BORDER);
        g.fill(left - 2, top - 2, right + 2, top + 252, OUTER);
        g.fill(left, top, right, top + 31, PANEL_LIGHT);
        g.fill(left, top + 33, right, top + 145, PANEL);
        g.fill(left, top + 147, right, top + 177, PANEL_LIGHT);

        g.drawString(font, "VIBEX", left + 10, top + 9, WHITE, true);
        g.drawString(font, "AUCTION", left + 57, top + 9, MUTED, true);
        g.drawString(font, "Deine Auktion. Dein Gewinn.", right - 145, top + 10, MUTED, false);

        // Item preview panel
        g.fill(left + 8, top + 39, left + 86, top + 119, BORDER);
        g.fill(left + 10, top + 41, left + 84, top + 117, PANEL_LIGHT);
        g.drawCenteredString(font, "ITEM", left + 47, top + 72, WHITE);
        String item = HugoAuctionClient.STATE.itemName();
        g.drawCenteredString(font, item.length() > 12 ? item.substring(0, 12) : item, left + 47, top + 91, MUTED);

        g.drawString(font, "Dauer:", left + 100, top + 39, WHITE, false);
        g.drawString(font, "Mindestgebot ($):", left + 100, top + 78, WHITE, false);

        // Live information area
        g.fill(left + 8, top + 183, right - 8, top + 250, BORDER);
        g.fill(left + 10, top + 185, right - 10, top + 248, PANEL);
        var state = HugoAuctionClient.STATE;
        g.drawString(font, "Aktuelles Gebot:", left + 18, top + 192, WHITE, false);
        g.drawString(font, state.highestBid() > 0 ? "$" + state.highestBid() : "—", left + 18, top + 207, WHITE, true);
        g.drawString(font, "Bieter: " + (state.highestBidder().isEmpty() ? "—" : state.highestBidder()), left + 18, top + 226, MUTED, false);
        g.drawString(font, "Gesamt: $" + state.totalIncome(), left + 170, top + 226, MUTED, false);

        // Compact leaderboard
        g.fill(right - 103, top + 39, right - 8, top + 145, BORDER);
        g.fill(right - 101, top + 41, right - 10, top + 143, PANEL);
        g.drawCenteredString(font, "RANGLISTE", right - 55, top + 45, WHITE);
        int y = top + 59;
        int rank = 1;
        for (var entry : state.ranking()) {
            if (rank > 5) break;
            g.drawString(font, rank + ". " + trim(entry.getKey(), 9), right - 96, y, rank == 1 ? WHITE : MUTED, rank == 1);
            g.drawString(font, "$" + entry.getValue(), right - 45, y, WHITE, false);
            y += 15;
            rank++;
        }
        if (rank == 1) g.drawString(font, "Noch keine Gebote", right - 96, y, MUTED, false);

        long remaining = Math.max(0, state.remainingMillis() / 1000);
        g.drawString(font, "Restzeit: " + String.format("%02d:%02d", remaining / 60, remaining % 60), left + 190, top + 193, WHITE, true);
        g.drawString(font, "Einnahmen: $" + state.totalIncome(), left + 190, top + 208, MUTED, false);
        g.drawString(font, "VIBEX  Creator", left + 10, top + 163, WHITE, true);
        g.drawString(font, "Alle Beträge in $", right - 105, top + 163, MUTED, false);

        super.render(g, mouseX, mouseY, delta);
    }

    private static String trim(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max - 1) + "…";
    }

    @Override
    public boolean isPauseScreen() { return false; }
}

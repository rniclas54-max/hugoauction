package de.vibex.hugoauction;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ChatParser {
    private static final Pattern[] PATTERNS = new Pattern[] {
        Pattern.compile("(?i)^([A-Za-z0-9_]{1,16}) hat dir \\$([0-9][0-9,]*) gesendet\\.?$"),
        Pattern.compile("(?i)^Du hast \\$([0-9][0-9,]*) von ([A-Za-z0-9_]{1,16}) erhalten\\.?$"),
        Pattern.compile("(?i)^([A-Za-z0-9_]{1,16}) sent you \\$([0-9][0-9,]*)\\.?$"),
        Pattern.compile("(?i)^You received \\$([0-9][0-9,]*) from ([A-Za-z0-9_]{1,16})\\.?$")
    };
    private ChatParser() {}
    public static Optional<Payment> parsePayment(String line) {
        if (line == null) return Optional.empty();
        String clean = line.replaceAll("§.", "").trim();
        for (int i = 0; i < PATTERNS.length; i++) {
            Matcher m = PATTERNS[i].matcher(clean);
            if (!m.matches()) continue;
            try {
                String name = (i == 0 || i == 2) ? m.group(1) : m.group(2);
                String amountText = (i == 0 || i == 2) ? m.group(2) : m.group(1);
                int amount = Integer.parseInt(amountText.replace(",", ""));
                return Optional.of(new Payment(name, amount));
            } catch (RuntimeException ignored) { return Optional.empty(); }
        }
        return Optional.empty();
    }
    public record Payment(String name, int amount) {}
}
